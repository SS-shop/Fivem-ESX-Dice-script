**ss-dice** A simple script for FiveM [ESX] dice rolling includes registering a command that generates random dice values

## How to Install

1. **Download** the latest release. 
2. **Extract** the files into your FiveM resources folder.
3. **Restart** you fivem server to apply all your changes.

[discord](https://discord.gg/5eJrHGH2)
[youtube](https://www.youtube.com/@sparki3)


